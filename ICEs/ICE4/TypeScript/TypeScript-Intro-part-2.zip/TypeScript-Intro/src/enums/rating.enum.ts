export enum Rating {
    G = "G",
    PG = "PG",
    PG13 = "PG12",
    R = "R",
    NC17 = "NC-17"
}